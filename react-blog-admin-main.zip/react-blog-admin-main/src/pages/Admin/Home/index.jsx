import Welcome from '../../../components/Content/Main/Welcome';
import Infor from '../../../components/Content/Main/Infor';
import MyNotice from '../../../components/Content/Main/MyNotice';
import Statistic from '../../../components/Content/Main/Statistic';
import Chart from '../../../components/Content/Main/Chart';
import Class from '../../../components/Content/Main/Class';
import MyTag from '../../../components/Content/Main/MyTag';
import MyNavLink from '../../../components/MyNavLink';
import './index.css';

const Home = () => (
    <>
        <div className="outlineBox">
            <Welcome />
            <Infor />
            <MyNotice />
        </div>

        <div className="statisticRegion">
            <MyNavLink to="/admin/article" className="homeLink">
                <Statistic type={'articles'} />
            </MyNavLink>
            <MyNavLink to="/admin/draft" className="homeLink">
                <Statistic type={'drafts'} />
            </MyNavLink>
            <MyNavLink to="/admin/link" className="homeLink">
                <Statistic type={'links'} />
            </MyNavLink>
            <MyNavLink to="/admin/msg" className="homeLink">
                <Statistic type={'msgs'} />
            </MyNavLink>
            <MyNavLink to="/admin/say" className="homeLink">
                <Statistic isRight={true} type={'says'} />
            </MyNavLink>
        </div>
        <div className="chart-class-tag">
            <Chart />
            <Class />
            <MyTag />
        </div>
    </>
);

export default Home;
