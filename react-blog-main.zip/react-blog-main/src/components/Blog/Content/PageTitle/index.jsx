import './index.css';

const PageTitle = ({ title }) => <div className="PageTitle-box">{title}</div>;

export default PageTitle;
