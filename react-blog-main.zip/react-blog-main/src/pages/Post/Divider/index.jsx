import './index.css';

const Divider = () => <div className="Divider"></div>;

export default Divider;
